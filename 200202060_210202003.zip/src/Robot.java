public class Robot {

    int x;
    int y;

}
